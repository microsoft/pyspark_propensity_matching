import setuptools

setuptools.setup(
    name="propensity_matching",
    version="0.2.0",

    author="Ruben Aghayan",
    author_email="ruaghaya@microsoft.com",

    packages=setuptools.find_packages(),
)